package ejercicioHilos3;

public class Test {
    public static void main(String[] args) {
        Hilo h = new Hilo();
        h.run();
    }

}