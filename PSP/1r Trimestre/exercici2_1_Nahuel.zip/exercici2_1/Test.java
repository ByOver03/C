package exercici2_1;

public class Test {
    public static void main(String[] args) {
        HiloTIC hTic = new HiloTIC();
        HiloTAC hTac = new HiloTAC();
        
        hTac.start();
        hTic.start();
    }
}
